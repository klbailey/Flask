from flask import Flask, render_template, redirect, url_for, session, request

app = Flask(__name__)
# Set a secret key for session security
app.secret_key = 'mysecret_key'  

# https://www.geeksforgeeks.org/how-to-use-flask-session-in-python-flask/
# https://stackoverflow.com/questions/52620992/how-can-i-make-a-non-permanent-session-in-flask
# Main logic, counter value stored in session, if nonexistent initialized to 0
@app.route('/')
def index():
    if 'counter' not in session:
        session['counter'] = 0
    return render_template('index.html', counter=session['counter'])

# Modify counter (adds 2) and redirect to index route
@app.route('/addTwo', methods=['POST'])
def addTwo():
    if request.method == 'POST':
        session['counter'] += 2
        return redirect(url_for('index'))
    return render_template('addTwo.html', counter=session['counter'])

# Modify counter (resets) and redirect to index route
@app.route('/reset', methods={'POST'})
def reset():
    if request.method == 'POST':
        session['counter'] = 0
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True, port = 5000)


